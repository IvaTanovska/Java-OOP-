package Hotel;

public class PriceCalculator {

    public static double calculate (double pricePreDay, int numberOfDays, Season season, Discount discount){
        double basedPrice = pricePreDay*numberOfDays*season.getMultiplier();
        return basedPrice*(1-discount.getDiscount());
    }
}
