package PointInRectangle;

import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] coordinatesArr = Arrays.stream(scanner.nextLine().split(" "))
                .mapToInt(Integer::parseInt)
                .toArray();

        //"{bottomLeftX} {bottomLeftY} {topRightX} {topRightY}".
        int bottomLeftX = coordinatesArr[0];
        int bottomLeftY = coordinatesArr[1];
        int topRightX = coordinatesArr[2];
        int topRightY = coordinatesArr[3];

       Point pointBottomLeft = new Point(bottomLeftX ,bottomLeftY);
       Point pointTopRight = new Point(topRightX,topRightY);

       Rectangle rectangle = new Rectangle(pointBottomLeft,pointTopRight);


       int n = Integer.parseInt(scanner.nextLine());
        for (int i = 0; i <n ; i++) {
            Point current= PointUtil.parsePoint(scanner.nextLine());

            System.out.println(rectangle.contains(current));


        }
    }
}
