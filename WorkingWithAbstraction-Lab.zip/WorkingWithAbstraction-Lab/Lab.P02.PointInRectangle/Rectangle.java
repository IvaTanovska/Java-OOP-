package PointInRectangle;

public class Rectangle {
    private Point bottomLeft;
   private Point topRight;

    public Rectangle(Point bottomLeft, Point topRight) {
        this.bottomLeft = bottomLeft;
        this.topRight = topRight;
    }

    public boolean contains(Point p){
        boolean isXInside = p.getCoordinatesX() >= this.bottomLeft.getCoordinatesX() && p.getCoordinatesX() <= this.topRight.getCoordinatesX();
        boolean isYInside = p.getCoordinatesY() >= this.bottomLeft.getCoordinatesY() && p.getCoordinatesY() <= this.topRight.getCoordinatesY();
        return isXInside&& isYInside;
    }

}
