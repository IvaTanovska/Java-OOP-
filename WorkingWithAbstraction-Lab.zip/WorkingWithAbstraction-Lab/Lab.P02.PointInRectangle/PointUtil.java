package PointInRectangle;

public class PointUtil {

    public static Point parsePoint (String input){
        String [] partsInput= input.split("\\s+");
        int x = Integer.parseInt(partsInput[0]);
        int y = Integer.parseInt(partsInput[1]);
        return new Point(x,y);

    }
}
